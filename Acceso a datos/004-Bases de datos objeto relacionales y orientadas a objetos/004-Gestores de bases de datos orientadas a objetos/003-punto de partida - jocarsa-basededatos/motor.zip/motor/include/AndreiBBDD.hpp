#pragma once
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include <filesystem>

class AndreiSerializador {
public:
    std::string serializar(const std::vector<std::string>& lista, char delimitador = ',') const;
    std::vector<std::string> desserializar(const std::string& cadena, char delimitador = ',') const;
};

struct ClaveForanea {
    std::string columna;
    std::string tablaReferenciada;
    std::string columnaReferenciada;
};

struct RestriccionColumna {
    bool noNulo = false;
    bool unico = false;
    bool tieneDefecto = false;
    std::string valorDefecto;
};



enum class TipoDato { TEXTO, ENTERO, REAL, BOOLEANO, FECHA, DECIMAL };

struct DefinicionColumna {
    std::string nombre;
    TipoDato tipo = TipoDato::TEXTO;
};

struct IndiceSecundario {
    std::string nombre;
    std::string columna;
};

struct ResultadoConsulta {
    std::vector<std::string> columnas;
    std::vector<std::vector<std::string>> filas;
};

class AndreiBBDD {
public:
    std::string instalacion;
    std::string basededatos;
    std::size_t tamanoRegistro = 512;

    explicit AndreiBBDD(const std::string& config = "config.json");
    bool crearColeccion(const std::string& nombre);
    bool crearSubcoleccion(const std::string& padre, const std::string& nombre);
    bool moverColeccion(const std::string& nombre, const std::string& nuevoPadre);
    std::vector<std::string> subcoleccionesDe(const std::string& nombre) const;
    std::vector<std::string> tablasDeColeccionRecursiva(const std::string& nombre) const;
    std::string arbolColecciones() const;
    bool eliminarColeccion(const std::string& nombre);
    std::vector<std::string> listarColecciones() const;
    bool agregarTablaColeccion(const std::string& tabla, const std::string& coleccion);
    bool quitarTablaColeccion(const std::string& tabla, const std::string& coleccion);
    std::vector<std::string> tablasDeColeccion(const std::string& coleccion) const;
    std::vector<std::string> coleccionesDeTabla(const std::string& tabla) const;
    bool creaBaseDatos(const std::string& nombre);
    bool usaBaseDatos(const std::string& nombre);
    std::vector<std::string> listarBases() const;
    std::vector<std::string> listarTablas() const;
    bool creaTabla(const std::string& nombre, const std::string& esquema);
    bool creaTablaTipada(const std::string& nombre, const std::vector<DefinicionColumna>& columnas);
    std::map<std::string,TipoDato> obtenerTipos(const std::string& tabla) const;
    bool crearVista(const std::string& nombre, const std::string& consulta);
    bool eliminarVista(const std::string& nombre);
    std::vector<std::string> listarVistas() const;
    bool iniciarTransaccion();
    bool confirmarTransaccion();
    bool deshacerTransaccion();
    bool enTransaccion() const { return transaccionActiva; }
    bool crearIndice(const std::string& nombre, const std::string& tabla, const std::string& columna);
    bool eliminarIndice(const std::string& nombre, const std::string& tabla);
    std::vector<IndiceSecundario> listarIndices(const std::string& tabla) const;
    std::string explicar(const std::string& consulta) const;
    bool alteraTablaAnadir(const std::string& tabla, const std::string& columna);
    bool alteraTablaEliminarColumna(const std::string& tabla, const std::string& columna);
    bool alteraTablaRenombrarColumna(const std::string& tabla, const std::string& antigua, const std::string& nueva);
    bool alteraTablaModificarColumna(const std::string& tabla, const std::string& antigua, const std::string& nueva);
    bool truncarTabla(const std::string& tabla);
    bool eliminarTabla(const std::string& tabla);
    bool eliminarBaseDatos(const std::string& nombre);
    bool anadirClaveForanea(const std::string& tabla, const std::string& columna, const std::string& tablaReferenciada, const std::string& columnaReferenciada = "id");
    std::vector<ClaveForanea> obtenerClavesForaneas(const std::string& tabla) const;
    RestriccionColumna obtenerRestricciones(const std::string& tabla, const std::string& columna) const;
    bool establecerNoNulo(const std::string& tabla, const std::string& columna);
    bool establecerUnico(const std::string& tabla, const std::string& columna);
    bool establecerPorDefecto(const std::string& tabla, const std::string& columna, const std::string& valor);
    std::string obtenerClavePrimaria(const std::string& tabla) const;
    std::vector<std::string> obtenerEsquema(const std::string& tabla) const;
    long long siguienteId(const std::string& tabla) const;
    long long insertarDatos(const std::string& tabla, const std::vector<std::string>& datos);
    long long insertarConColumnas(const std::string& tabla, const std::vector<std::string>& columnas, const std::vector<std::string>& valores);
    long long insertarDesdeSeleccion(const std::string& destino, const std::string& origen);
    long long actualizarDonde(const std::string& tabla, const std::map<std::string,std::string>& cambios, const std::string& columnaDonde = "", const std::string& valorDonde = "");
    long long eliminarDonde(const std::string& tabla, const std::string& columnaDonde = "", const std::string& valorDonde = "");
    std::int64_t buscarPosicion(const std::string& tabla, long long id) const;
    std::vector<std::string> leerRegistro(const std::string& tabla, long long id) const;
    std::map<std::string,std::string> seleccionar(const std::string& tabla, long long id) const;
    std::vector<std::map<std::string,std::string>> listarTodo(const std::string& tabla) const;
    ResultadoConsulta consultar(const std::string& consulta) const;
    std::vector<std::map<std::string,std::string>> buscarColumna(const std::string& tabla, const std::string& columna, const std::string& valor) const;
    bool actualizar(const std::string& tabla, long long id, const std::vector<std::string>& datos);
    bool eliminar(const std::string& tabla, long long id);

private:
    bool transaccionActiva = false;
    std::string baseTransaccion;
    std::filesystem::path rutaSnapshot;
    bool validarTipo(TipoDato tipo, const std::string& valor) const;
    std::string normalizarTipo(TipoDato tipo, const std::string& valor) const;
    ResultadoConsulta consultarInterno(const std::string& consulta, int profundidad) const;
    bool esVista(const std::string& nombre) const;
    std::string consultaVista(const std::string& nombre) const;
    std::string rutaTabla(const std::string& tabla, const std::string& extension) const;
    std::string prepararRegistro(const std::vector<std::string>& elementos) const;
    static std::string trimDerecha(std::string s);
    bool validarClavesForaneas(const std::string& tabla, const std::vector<std::string>& datos) const;
    bool prepararYValidarRestricciones(const std::string& tabla, std::vector<std::string>& datos, long long idIgnorar = -1) const;
    bool registroReferenciado(const std::string& tabla, const std::string& columna, const std::string& valor) const;
    bool puedeEliminarRegistro(const std::string& tabla, const std::map<std::string,std::string>& registro) const;
    void reconstruirIndices(const std::string& tabla) const;
    std::vector<long long> buscarIdsIndice(const std::string& tabla, const std::string& columna, const std::string& valor) const;
};
